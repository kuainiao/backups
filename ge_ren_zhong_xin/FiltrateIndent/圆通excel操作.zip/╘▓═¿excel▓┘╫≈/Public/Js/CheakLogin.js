function CheckIn()
{
    var oUser = document.form.user.value;
    var oPwd = document.form.pwd.value;
    var oDiv = document.getElementById('hidden');

    if(/^[a-zA-Z\d]{6,11}$/.test(oUser) === false || oUser === '' || /^[a-zA-Z\d]{6,11}$/.test(oPwd) === false || oPwd === ''){
        oDiv.style.display = 'block';
        return false;
    } 
}

function ClearNotice()
{
    var oUser = document.getElementsByName('user')[0];
    var oPwd = document.getElementsByName('pwd')[0];
    var oDiv = document.getElementById('hidden');

        oUser.onmouseover = oPwd.onmouseover = function()
        {
            oDiv.style.display = 'none';
        }
}

window.onload = function()
{   
    ClearNotice();
}
