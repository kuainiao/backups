function GetStyle(obj, attr)
{
    if(obj.currentStyle)
    {
        return obj.currentStyle[attr];
    }
    else
    {
        return getComputedStyle(obj, false)[attr];
    }
}

function ChanegDivStyle()
{
    var obj = document.getElementsByClassName('ExcelFather');
    if(obj)
    {   
        var nBodyHeight = document.documentElement.clientHeight;
 
        if(nBodyHeight)
        {
            var nMargin = '';
            var nLen1 = obj.length;
            var i = 0;
            for(i; i < nLen1; i ++)
            {
                obj[i].index = i;
                nMargin = (nBodyHeight - parseInt(GetStyle(obj[i], 'height')) - 156) / 2;

                obj[i].style.marginTop = nMargin > 5 ? nMargin + 'px': 32 + 'px';
                obj[i].style.marginBottom = nMargin > 5 ? nMargin + 'px': 132 + 'px';
            }
        }
    }
}

function ChangeDisplay(arg1)
{
    if(arg1)
    {
        var obj1 = document.getElementsByClassName('ExcelFather');
        var obj2 = document.getElementById(arg1);
        if(obj1 && obj2)
        {
            var nLen1 = obj1.length;
            var i = 0;
            for(i; i < nLen1; i ++)
            {
                obj1[i].index = i;
                obj1[i].style.display = 'none';
            }
            obj2.style.display = 'block';
        }
    }
}

function AddHandInput(obj)
{
    var oForm = document.getElementById(obj);

    if(oForm)
    {
        var obj1 = document.createElement('span');
        var obj2 = document.createElement('input');
        var nLen1 = oForm.getElementsByTagName('input').length * 1 + 1;

        if(obj1 && obj2)
        {  
            obj1.innerHTML = '第&nbsp;&nbsp;' + nLen1 + '&nbsp;&nbsp;列数据名';
            obj2.placeholder = '请注意不要填写错误，后果自负';
            obj2.name = 'info[]';

            oForm.appendChild(obj1);
            oForm.appendChild(obj2);
        }
    }
}

window.onload = window.onresize = function()
{   
    ChanegDivStyle();
}

function CheckFileType(tag, File)
{
    if(tag === '1')
    {
        var oInput = document.getElementsByName(File)[0];
        if(oInput.value === '')
        {
            return false;
        }
    }
    else if(tag === '2')
    {
        var oFileName = File.value;
        if(oFileName.length > 1 && oFileName) 
        {       
            var oSubstr = oFileName.lastIndexOf(".");
            var type = oFileName.substring(oSubstr + 1);
             
            if(type !== 'xls' && type !== 'xlsx') 
            {
                File.outerHTML = File.outerHTML.replace(/(value=\").+\"/i,"$1\"");
            }       
        }
    }
}