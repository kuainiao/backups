<?php
namespace Home\Controller;
use Think\Controller;
class BeforeController extends Controller 
{
    protected function _initialize()
    {   
        if(empty($_SESSION['id']) || empty($_SESSION['name']) || empty($_SESSION['sta']) || empty($_SESSION['r_time']) || empty($_SESSION['last_time']) || empty($_SESSION['last_ip']) || $_SESSION['CheckName'] !== md5($_SESSION['name'] . 'shenshuang'))
        {
            echo '<center>';
            $this->redirect('Index/index', null, 3, '请重新登陆');
            echo '</center>';
        }
    }

    protected function CheckAdmin($jump1, $jump2)
    {
        $CheckJurisdiction = $_SESSION['CheckJurisdiction'];
        $Admin = md5($_SESSION['jurisdiction'] . 'shenshuang');
        if($CheckJurisdiction !== $Admin)
        {   
            $_SESSION = array();
        }
        else
        {
            if($_SESSION['jurisdiction'] === 'admin')
            {
                $this->display($jump1);
            }
            else
            {
                $this->display($jump2);
            }
        }
    }

    protected function ReturnJudge($msg = '', $jump = '')
    {
        echo '<center>';
        if(empty($jump))
        {
            $this->error($msg);
        }
        else
        {
            $this->success($msg, $jump);
        }
        echo '</center>';
    }

    public function LoginOut()
    {
        $_SESSION = array();
        $this->_initialize();
    }

    protected function GetIp()
    {
        global $ip;
        if(getenv("HTTP_CLIENT_IP"))
        {
            $ip = getenv("HTTP_CLIENT_IP");
        }
        else if(getenv("HTTP_X_FORWARDED_FOR"))
        {
            $ip = getenv("HTTP_X_FORWARDED_FOR");
        }
        else if(getenv("REMOTE_ADDR"))
        {
            $ip = getenv("REMOTE_ADDR");
        }
        else 
        {
            $ip = "Unknow";
        }
        return $ip;
    }

    protected function ImportExcel($file)
    {
        $type = pathinfo($file); 
        $type = strtolower($type["extension"]);
        if($type == 'xlsx') 
        { 
            $type = 'Excel2007'; 
        } 
        elseif($type == 'xls')
        { 
            $type = 'Excel5'; 
        }

        ini_set('max_execution_time', '0');
        Vendor('PHPExcel.PHPExcel');

        $objReader = \PHPExcel_IOFactory::createReader($type);
        $objPHPExcel = $objReader->load($file); 
        $sheet = $objPHPExcel->getSheet(0); 

        $highestRow = $sheet->getHighestRow();     
        $highestColumn = $sheet->getHighestColumn(); 
        $data=array();
        for($j=1;$j<=$highestRow;$j++)
        {
            for($k='A';$k<=$highestColumn;$k++)
            {
                $data[$j][]=$objPHPExcel->getActiveSheet()->getCell("$k$j")->getValue();
            } 
        }  
        return $data;
    }

    protected function ExportExcel($data, $FileName = 'simple')
    {
        ini_set('max_execution_time', '0');
        Vendor('PHPExcel.PHPExcel');

        $PhpExcel = new \PHPExcel();

        $PhpExcel->getProperties()
                 ->setCreator("Maarten Balliauw")
                 ->setLastModifiedBy("Maarten Balliauw")
                 ->setTitle("Office 2007 XLSX Test Document")
                 ->setSubject("Office 2007 XLSX Test Document")
                 ->setDescription("Test document for Office 2007 XLSX, generated using PHP classes.")
                 ->setKeywords("office 2007 openxml php")
                 ->setCategory("Test result file");
        $PhpExcel->getActiveSheet()->fromArray($data);
        $PhpExcel->getActiveSheet()->setTitle('Sheet1');
        $PhpExcel->setActiveSheetIndex(0);

        header('Content-Type: application/vnd.ms-excel');
        header("Content-Disposition: attachment;FileName=$FileName");
        header('Cache-Control: max-age=0');
        header('Cache-Control: max-age=1');
        header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT');
        header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT');
        header ('Cache-Control: cache, must-revalidate');
        header ('Pragma: public');

        $objwriter = \PHPExcel_IOFactory::createWriter($PhpExcel, 'Excel5');
        $objwriter->save('php://output');

        exit;
    }

    protected function PreventSql($info)
    {
        if(is_array($info))
        {
            $data = array();
            foreach($info as $k => $v)
            {
                $data[$k] = $this->RePlaceStr($v);
            }
        }
        else
        {
            $data = $this->RePlaceStr($info);
        }
        return $data;
    }

    private function RePlaceStr($str)
    {
        $str = str_replace('and','',$str);
        $str = str_replace('execute','',$str);
        $str = str_replace('count','',$str);
        $str = str_replace('chr','',$str);
        $str = str_replace('mid','',$str);
        $str = str_replace('master','',$str);
        $str = str_replace('truncate','',$str);
        $str = str_replace('char','',$str);
        $str = str_replace('declare','',$str);
        $str = str_replace('create','',$str);
        $str = str_replace('insert','',$str);
        $str = str_replace('delete','',$str);
        $str = str_replace('update','',$str);
        $str = str_replace('select','',$str);
        $str = str_replace('find','',$str);
        $str = str_replace('or','',$str);
        $str = str_replace('"','',$str);
        $str = str_replace("'",'',$str);
        $str = str_replace('=','',$str);
        $str = str_replace(' ','',$str); 
        $str = str_replace(';','',$str); 
        return $str;
    }
    
    protected function SaveAll($SaveWhere, &$SaveData, $TableName)
    {
        if($SaveWhere == null || $TableName == null)
        {
            return false;
        }
        $key = array_keys($SaveWhere)[0];
        $len = count($SaveWhere[$key]);
        $flag = true;
        $model = M($TableName);
        $model->startTrans();
        $error = [];
        for($i = 0; $i < $len; $i++)
        {
            $isRight = $model->where($key.'='.$SaveWhere[$key][$i])->save($SaveData[$i]);
  
            if($isRight == 0)
            {
                $error[] = $i;
                $flag = false;
            }
        }

        if($flag)
        {
            $model->commit();
            return $SaveWhere;
        }
        else if(count($error)>0&count($error)<$len)
        {
            $model->rollback();
            for($i = 0; $i < count($error); $i++)
            {
                unset($SaveWhere[$key][$error[$i]]);
                unset($SaveData[$error[$i]]);
            }
            $SaveWhere[$key] = array_merge($SaveWhere[$key]);
            $SaveData = array_merge($SaveData);
            $this->saveAll($SaveWhere, $SaveData, $TableName);
            return $SaveWhere;
        }
        else
        {
            $model->rollback();
            return false;
        }
    }  

    protected function ArraYDif($arr1, $arr2) 
    {
        $ArrTemp1 = $arr1;
        $ArrTemp2 = $arr2;

        $ArrTemp2 = array_flip($ArrTemp2);
        foreach($ArrTemp1 as $key => $item) 
        {   
            if(isset($ArrTemp2[$item]) && $ArrTemp2[$item] == $key) 
            {
                unset($ArrTemp1[$key]);
            }
        }
        if(!empty($arr1))
        {
            $dif = $ArrTemp1;
        }
        else
        {
            $arr1 = array_flip($arr1);
            foreach($arr2 as $key => $item) 
            {   
                if(isset($arr1[$item]) && $arr1[$item] == $key) 
                {
                    unset($arr2[$key]);
                }
            }
            $dif = $arr2;
        }
        return $dif;
    }
    
    protected function CreateDataTag($table)
    {
        $Model = M($table);
        $tag = $_SESSION['id']. '_' .time();
        $sql = 'select d_tag from ' . $table . " where d_tag = '$tag' ";

        return $Model->query($sql)?$this->CreateDataTag():$tag;
    }   

    protected function ArraySort($arr, $keys, $type = 'desc') 
    {
        $keysvalue = $new_array = array();

        foreach($arr as $k => $v) 
        {
            $keysvalue[$k] = $v[$keys];
        }

        if($type == 'asc') 
        {
            asort($keysvalue);
        } 
        else 
        {
            arsort($keysvalue);
        }

        reset($keysvalue);

        foreach($keysvalue as $k => $v) 
        {
            $new_array[$k] = $arr[$k];
        }
        
        return $new_array;
    }
}