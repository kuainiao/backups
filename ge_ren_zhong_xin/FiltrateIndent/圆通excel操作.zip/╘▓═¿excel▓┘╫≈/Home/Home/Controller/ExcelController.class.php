<?php
namespace Home\Controller;
use Think\Controller;
class ExcelController extends BeforeController 
{
    public function index() 
    {
        $this->CheckAdmin('index', 'index1');
    }

    public function DoHandAdd()
    {
        $who = I('get.temp');
        $info1 = I('post.');

        $info = array();
        foreach($info1['info'] as $k => $v)
        {
            if(!empty($v))
            {
                $info[$k] = $v;
            }
        }
        if(empty($info))
        {
            $this->ReturnJudge('提交信息为空', 'index');
            exit();
        }
        $this->InsertTemp($who, $info);
    }

    public function DoExcelAdd()
    {
        $who = I('get.temp');
        $up = new \Think\Upload();
        $up->maxSize  = 3145728 ;
        $up->exts     = array('xlsx', 'xls');
        $up->rootPath = './Uploads/excel/'; 
        $up->savePath = ''; 
        $up->saveName = date('Y-m-d H-i-s', time()) . '_' . mt_rand();
        $res1 = $up->upload();
        if(!$res1) 
        {
            $this->ReturnJudge($up->getError());
            exit();
        }
        else
        {
            $file = '';
            foreach($res1 as $v){
                $file = 'Uploads/excel/'.$v['savepath'].$v['savename'];
            }

            $data = $this->ImportExcel($file);
            $data = $this->PreventSql($data);
            if($who === 'myself' || $who === 'express')
            {
                $this->InsertTemp($who, $data[1]);
            }
            else if($who === 'MyData' || $who === 'ExData')
            {
                $this->InsertData($who, $data);
            }
            else
            {
                $this->ReturnJudge('what are you 弄啥勒？', 'index');
                exit();
            }

        }
    }

    public function InsertTemp($who, $info)
    {
        if($who === 'myself')
        {
            $who = 's';
            $Temp = M('self_temp');
        }
        else if($who === 'express')
        {
            $who = 'e';
            $Temp = M('yuantong_temp');
        }
        else
        {
            $this->ReturnJudge('你谁啊');
            exit();
        }

        $where1['sta'] = 1;
        
        $res1 = $Temp->where($where1)->max('tag');
        if($res1)
        {
            $_SESSION["$TempBeForeTag"] = $res1;
            $MaxTag = $res1 + 1;
        }
        else
        {
            $MaxTag = 1;
        }
        $_SESSION['TempInsertTag'] = $MaxTag;
        foreach($info as $k => $v)
        {
            $info[$k] = $k.'TitValueInterval'.$v;
        }
        $name = implode('ArrayInterval', $info);
        $name1 = $this->PreventSql($name);
        $name2 = explode('ArrayInterval', $name1);

        $info2 = array();
        foreach($name2 as $v)
        {
            $key = explode('TitValueInterval', $v)[0];
            $val = explode('TitValueInterval', $v)[1];
            $info2[$key] = $val;
        }

        $data2 = array();
        $time = time();
        foreach($info2 as $k => $v)
        {
            $data2[$k]['w_ad'] = $_SESSION['id'];
            $data2[$k]['a_t'] = $time;
            $data2[$k]['tag'] = $MaxTag;
            $data2[$k]['sta'] = 1;
            $data2[$k]['line'] = $k + 1;
            $data2[$k]['l_val'] = $v;
        }

        $data2 = array_values($data2);
        $where3['tag'] = $_SESSION["$TempBeForeTag"];
        if(!empty($where3['tag']))
        {   
            $data3['sta'] = 0;
            $res3 = $Temp->where($where3)->save($data3);

            $data4['sta'] = 1;  
            if($res3 === false)
            {   
                $Temp->where($where3)->save($data4);

                $this->ReturnJudge('更新出错，请重新操作', 'index');
                exit();
            }
            else
            {   
                $res2 = $Temp->addAll($data2);
                if($res2)
                {
                    $this->ReturnJudge('添加模版成功', 'index');
                    exit();
                }
                else
                {
                    $where4['tag'] = $_SESSION['TempInsertTag'];
                    $Temp->where($where4)->delete();
                    $Temp->where($where3)->save($data4);

                    $this->ReturnJudge('添加模版失败', 'index');
                    exit();
                }
            }
        }
        else
        {
            $res2 = $Temp->addAll($data2);
            if($res2)
            {
                $this->ReturnJudge('添加模版成功', 'index');
                exit();
            }
            else
            {
                $where4['tag'] = $_SESSION['TempInsertTag'];
                $Temp->where($where4)->delete();

                $this->ReturnJudge('添加模版失败', 'index');
                exit();
            }
        }
    }

    public function InsertData($who, $data)
    {
        if($who === 'MyData')
        {
            $Temp = M('self_temp');
            $TagModel = M('self_data_tag');
            $DataModel = M('self_data');
        }
        else if($who === 'ExData')
        {
            $Temp = M('yuantong_temp');
            $TagModel = M('yuantong_data_tag');
            $DataModel = M('yuantong_data');
        }
        else
        {
            $this->ReturnJudge('不认你', 'index');
            exit();
        }

        $where1['sta'] = 1;
        $res1 = $Temp->where($where1)->select();
        if($res1)
        {
            $val = array();
            foreach($res1 as $v)
            {
                $val[] = $v["l_val"];
            }
        }
        else
        {
            $this->ReturnJudge('当前模版配置为空', 'index');
            exit();
        }
        $diff = $this->ArraYDif($val, $data[1]);
        if($diff)
        {   
            $this->ReturnJudge('当前模版配置与当前文件的标题不同，请仔细检查', 'index');
            exit();
        }
        else
        {   
            $time = time();
            $data2['d_tag'] = $_SESSION['d_tag'] = $this->CreateDataTag('self_data_tag');
            $data2['w_ad'] = $_SESSION['id'];
            $data2['a_t'] = $time;

            $data2['s_tag'] = 1;

            $res2 = $TagModel->add($data2);
            if($res2)
            {
                unset($data[1]);
                if(empty($data))
                {
                    $this->ReturnJudge('添加数据不能为空', 'index');
                    exit();
                }
           
                $data22 = array();
                $data222 = array();
                
                if($who === 'ExData')
                {
                    foreach($data as $k => $v)
                    {
                        $data22['d_tags'] = $_SESSION['d_tag'];
                        $data22['l0'] = isset($v[0]) ? $v[0] : '';
                        $data22['l1'] = isset($v[1]) ? $v[1] : '';
                        $data22['l2'] = isset($v[2]) ? $v[2] : '';
                        $data22['l3'] = isset($v[3]) ? $v[3] : '';
                        $data22['l4'] = isset($v[4]) ? $v[4] : '';
                        $data22['l5'] = isset($v[5]) ? $v[5] : '';
                        $data22['l6'] = isset($v[6]) ? $v[6] : '';
                        $data22['l7'] = isset($v[7]) ? $v[7] : '';
                        $data22['l8'] = isset($v[8]) ? $v[8] : '';
                        $data22['l9'] = isset($v[9]) ? $v[9] : '';
                        $data22['l10'] = isset($v[10]) ? $v[10] : '';
                        $data22['l11'] = isset($v[11]) ? $v[11] : '';
                        $data22['l12'] = isset($v[12]) ? $v[12] : '';
                        $data22['l13'] = isset($v[13]) ? $v[13] : '';

                        $data222[] = $data22;
                    }    
                }
                else if($who === 'MyData')
                {
                    foreach($data as $k => $v)
                    {
                        $data22['d_tags'] = $_SESSION['d_tag'];
                        $data22['l0'] = isset($v[0]) ? $v[0] : '';
                        $data22['l1'] = isset($v[1]) ? $v[1] : '';
                        $data22['l2'] = isset($v[2]) ? $v[2] : '';
                        $data22['l3'] = isset($v[3]) ? $v[3] : '';
                        $data22['l4'] = isset($v[4]) ? $v[4] : '';
                        $data22['l5'] = isset($v[5]) ? $v[5] : '';
                        $data22['l6'] = isset($v[6]) ? $v[6] : '';
                        $data22['l7'] = isset($v[7]) ? $v[7] : '';
                        $data22['l8'] = isset($v[8]) ? $v[8] : '';
                        $data22['l9'] = isset($v[9]) ? $v[9] : '';
                        $data22['l10'] = isset($v[10]) ? $v[10] : '';
                        $data22['l11'] = isset($v[11]) ? $v[11] : '';
                        $data22['l12'] = isset($v[12]) ? $v[12] : '';
                        $data22['l13'] = isset($v[13]) ? $v[13] : '';
                        $data22['l14'] = isset($v[14]) ? $v[14] : '';
                        $data22['l15'] = isset($v[15]) ? $v[15] : '';
                        $data22['l16'] = isset($v[16]) ? $v[16] : '';
                        $data22['l17'] = isset($v[17]) ? $v[17] : '';
                        $data22['l18'] = isset($v[18]) ? $v[18] : '';
                        $data22['l19'] = isset($v[19]) ? $v[19] : '';
                        $data22['l20'] = isset($v[20]) ? $v[20] : '';
                        $data22['l21'] = isset($v[21]) ? $v[21] : '';
                        $data22['l22'] = isset($v[22]) ? $v[22] : '';
                        $data22['l23'] = isset($v[23]) ? $v[23] : '';

                        $data222[] = $data22;
                    }
                }

                $res22 = $DataModel->addALL($data222);
                if($res22)
                {
                    $this->ReturnJudge('添加数据成功', 'index');
                    exit();
                }
                else
                {
                    $where3['d_tag'] = $_SESSION['d_tag'];
                    $where33['d_tags'] = $_SESSION['d_tag'];
                    $res3 = $TagModel->where($where3)->delete();
                    $res33 = $DataModel->where($where33)->delete();
                    if($res3 && $res33)
                    {
                        $this->ReturnJudge('添加数据失败唲', 'index');
                        exit();
                    }
                    else
                    {
                        $this->ReturnJudge('请联系管理员', 'index');
                        exit();
                    }
                }
            }
            else
            {
                $this->ReturnJudge('添加数据失败咦', 'index');
                exit();
            }
        
        }
    }

    public function ShowTemp()
    {
        $who = $this->PreventSql(I('get.temp'));
        if($who === 'user')
        {
            $who = 1;
            $Temp = M('self_temp');
        }
        else if($who === 'express')
        {
            $who = 2;
            $Temp = M('yuantong_temp');
        }
        else
        {
            $this->ReturnJudge('你想干森么', 'index');
            exit();
        }
        $where1['sta'] = 1; 
        $res1 = $Temp->where()->max('tag');

        if($res1)
        {
            $where1['tag'] = $res1;
            $res2 = $Temp->where($where1)->select();

            if($res2)
            {
                $where3['u_id'] = $res2[0]['w_ad'];
                $Admin = M('Admin');
                $res3 = $Admin->where($where3)->getField('u_name');
                $time = $res2[0]['a_t'];

                $this->assign('who', $who);
                $this->assign('user', $res3);
                $this->assign('time', $time);
                $this->assign('info', $res2);
                $this->display();
            }
            else
            {
                $this->ReturnJudge('当前模版不存在', 'index');
                exit();
            }
        }  
        else
        {
            $this->ReturnJudge('当前模版为空', 'index');
            exit();
        }
    }

    public function UpdTemp()
    {
        $who = $this->PreventSql(I('get.temp'));
        $info1 = $this->PreventSql(I('post.'));

        if($who === '1')
        {
            $Temp = 'self_temp';
        }
        else if($who === '2')
        {
            $Temp = 'yuantong_temp';
        }
        else
        {
            $this->ReturnJudge('what are you 弄啥勒？', 'index');
            exit();
        }

        $data1 = array();
        $ids = array();
        foreach($info1 as $k => $v);
        {
            foreach($v as $key => $val)
            {
                if(!empty($val))
                {
                    $ids['id'][] = $key;
                    $data1[]['l_val'] = $val;
                }
            }
        }
        $time1 = time();
        foreach($data1 as $k => $v)
        {
            $data1[$k]['w_upd'] = $_SESSION['id'];
            $data1[$k]['u_t'] = $time1; 
        }
        $res1 = $this->SaveAll($ids, $data1, $Temp);
        if($res1)
        {
            $this->ReturnJudge('更新成功', 'index');
            exit();
        }
        else
        {
            $this->ReturnJudge('更新失败', 'index');
            exit();
        }
    }

    public function ScreenData()
    {
        $act = I('get.act');
        $act = $this->PreventSql($act);

        $where1['sta'] = 1;
        
        $Model = M('Screen');
        $res1 = $Model->where($where1)->getField('s_id, s_act, e_val, u_val, name');

        if($res1)
        {   
            if($act === 'screen')
            {
                $this->assign('screen', $res1);
                $this->CheckAdmin('ScreenData', 'ScreenData1');
            }
            else if($act === 'upds')
            {
                $ExpressTemp1 = array();
                $UserTemp1 = array();
                foreach($res1 as $k => $v)
                {
                    $ExpressTemp1[] = $v['e_val'];
                    $UserTemp1[] = $v['u_val'];
                    $data2[$k] = $v;
                }

                $UserTemp2 = array();
                foreach($UserTemp1 as $k => $v)
                {
                    if(!empty($v))
                    {
                        $UserTemp2[$v] = $v;
                    }
                }

                $ExpressTemp2 = array();
                foreach($ExpressTemp1 as $k => $v)
                {
                    if(!empty($v))
                    {
                        $ExpressTemp2[$v] = $v;
                    }
                }
                $where3['sta'] = $where33['sta'] = 1;
                $where3['line'] = array('in', implode(',', $UserTemp2));
                $where33['line'] = array('in', implode(',', $ExpressTemp2));

                $Model3 = M('self_temp');
                $Model33 = M('yuantong_temp');

                $res3 = $Model3->where($where3)->getField('line, l_val');
                $res33 = $Model33->where($where33)->getField('line, l_val');
                if(!$res3 || !$res33)
                {
                    $this->ReturnJudge('未知错误，请联系管理员', 'index');
                    exit();
                }

                $data22 = array();
                foreach($data2 as $k => $v)
                {
                    if(!empty($v['e_val']))
                    {
                        if(isset($res33[$v['e_val']]))
                        {
                            $v['value1'] = $res33[$v['e_val']];
                        }
                    }
                    if(!empty($v['u_val']))
                    {
                        if(isset($res3[$v['u_val']]))
                        {
                            $v['value2'] = $res3[$v['u_val']];
                        }
                    }
                    $data22[] = $v;
                }   
                $data222 = $this->GetTempSetting();

                $data2222 = array();
                foreach($data22 as $k => $v)
                {
                    $data2222[$k] = $v;
                    $data2222[$k]['UserTemp'] = $data222['UserTemp'];
                    $data2222[$k]['ExpressTemp'] = $data222['ExpressTemp'];
                }
                $this->assign('data', $data2222);
                $this->assign('sta', '修改');
                $this->display('ScreenSeted');
            }
        }
        else
        {
            $data1 = $this->GetTempSetting();
            $this->assign('sta', '当前筛选数据模版为空，请添加');
            $this->assign('data', $data1);
            $this->display('ScreenSet');
        }
    }

    public function GetTempSetting()
    {
        $where1['sta'] = 1;

        $Model1 = M('self_temp');
        $Model2 = M('yuantong_temp');

        $where2['tag'] = $Model1->where($where1)->max('tag');
        $where22['tag'] = $Model2->where($where1)->max('tag');

        $res1 = $Model1->where($where2)->select();
        $res2 = $Model2->where($where22)->select();

        if(!$res1)
        {
            $this->ReturnJudge('用户配置表为空，请更新用户配置表', 'index');
            exit();
        }
        else if(!$res2)
        {
            $this->ReturnJudge('快递配置表为空，请更新快递配置表', 'index');
            exit();
        }
        else if($res1 && $res2)
        {
            $data['UserTemp'] = $res1; 
            $data['ExpressTemp'] = $res2; 

            return $data;
        }
        else
        {
            $this->ReturnJudge('嘿嘿', 'index');
            exit();
        }
    }

    public function DoScreenData()
    {
        $info = I('post.');
        $act = I('get.act');
        $info = $this->PreventSql($info);
        $act = $this->PreventSql($act);
        foreach($info as $k => $v)
        {
            if($v['Express'] === 'shenshuang' && $v['User'] === 'shenshuang' && $v['name'] === '')
            {
                unset($info[$k]);
            }
        }
        if(empty($info))
        {
            $this->ReturnJudge('筛选配置数据不能为空', 'index');
            exit();
        }

        if($act === 'adds' || $act === 'upds')
        {
            $where1['sta'] = 1;
            $Model = M('Screen');
            $res1 = $Model->where($where1)->max('s_tag');

            if($res1)
            {
                $where3['s_tag'] = $_SESSION['s_tag'] = $res1;
                $data3['sta'] = 0;

                $res3 = $Model->where($where3)->save($data3);
                if($res3)
                {
                    $max = $res1 + 1;
                }
                else
                {
                    $this->ReturnJudge('更新配置表失败', 'index');
                    exit();
                }
            }
            else
            {
                $max = 1;
            }

            $time = time();
            $data2 = array();
            $data22 = array();

            foreach($info as $k => $v)
            {
                if($v['Express'] === 'shenshuang')
                {
                    $v['Express'] = '';
                }
                if($v['User'] === 'shenshuang')
                {
                    $v['User'] = '';
                }
                $data2['w_ad'] = $_SESSION['id'];
                $data2['a_t'] = $time;
                $data2['s_tag'] = $max;
                $data2['e_val'] = $v['Express'];
                $data2['u_val'] = $v['User'];
                $data2['name'] = $v['name'];
                $data2['s_act'] = $v['act'];
                $data2['sta'] = 1;

                $data22[] = $data2;
            }

            $res2 = $Model->addAll($data22);
            if($res2)
            {
                $this->ReturnJudge('添加筛选配置数据成功', 'index');
                exit();
            }
            else
            {
                $data4['sta'] = 1;
                $Model->where($where3)->save($data4);
                $where44['s_tag'] = $max;
                $Model->where($where44)->delete();
                $this->ReturnJudge('添加筛选配置数据失败', 'index');
                exit();
            }
        }
        else
        {
            $this->ReturnJudge('哈哈', 'index');
            exit();
        }
    }
}